# Smart Bus Tracking System

A complete beginner-friendly bus tracking project with:

- Frontend: HTML, CSS, JavaScript
- Backend: Python Flask
- Database: SQLite
- REST API: Flask JSON endpoints
- Responsive dashboard
- Bus search/filter
- Demo map-style visualization
- Sample bus records

## Project Structure

```text
Bus-Tracking-Complete-Project/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   └── images/
├── database/
│   ├── db.py
│   ├── seed.py
│   └── bus_tracking.db
├── api/
└── docs/
    └── API.md
```

## How to Run

1. Install Python 3.
2. Open Command Prompt in this project folder.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Start the server:

```bash
python app.py
```

5. Open:

```text
http://127.0.0.1:5000
```

## Important

The project currently uses sample GPS coordinates. For a true real-time hackathon system, a driver/mobile GPS client can send latitude and longitude to:

```text
PUT /api/buses/<id>/location
```

The database then stores the latest location.

## API Example

Update BUS101:

```json
{
  "latitude": 12.7415,
  "longitude": 77.8270,
  "speed": 40,
  "status": "Running"
}
```

Endpoint:

```text
PUT /api/buses/1/location
```
