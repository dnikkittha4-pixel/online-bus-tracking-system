let buses = [];

async function loadBuses() {
    try {
        const response = await fetch("/api/buses");
        if (!response.ok) throw new Error("API request failed");
        buses = await response.json();

        document.getElementById("apiStatus").textContent = "● API Connected";
        updateStats();
        renderTable();
        renderMarkers();

        document.getElementById("lastRefresh").textContent =
            new Date().toLocaleTimeString();
    } catch (error) {
        document.getElementById("apiStatus").textContent = "● API Error";
        console.error(error);
    }
}

function updateStats() {
    document.getElementById("totalBuses").textContent = buses.length;
    document.getElementById("runningBuses").textContent =
        buses.filter(b => b.status.toLowerCase() === "running").length;
    document.getElementById("stoppedBuses").textContent =
        buses.filter(b => b.status.toLowerCase() === "stopped").length;
}

function renderTable() {
    const search = document.getElementById("searchBox").value.toLowerCase();

    const filtered = buses.filter(bus =>
        bus.bus_number.toLowerCase().includes(search) ||
        bus.route.toLowerCase().includes(search) ||
        bus.driver_name.toLowerCase().includes(search)
    );

    const table = document.getElementById("busTable");
    table.innerHTML = filtered.map(bus => `
        <tr>
            <td><strong>${bus.bus_number}</strong></td>
            <td>${bus.route}</td>
            <td>${bus.driver_name}</td>
            <td>${Number(bus.latitude).toFixed(4)}, ${Number(bus.longitude).toFixed(4)}</td>
            <td>${bus.speed} km/h</td>
            <td><span class="badge ${bus.status.toLowerCase()}">${bus.status}</span></td>
            <td>${bus.last_updated}</td>
        </tr>
    `).join("");

    if (!filtered.length) {
        table.innerHTML = `<tr><td colspan="7">No buses found.</td></tr>`;
    }
}

function renderMarkers() {
    const holder = document.getElementById("busMarkers");
    holder.innerHTML = "";

    buses.forEach((bus, index) => {
        const marker = document.createElement("div");
        marker.className = "marker";
        marker.title = `${bus.bus_number} - ${bus.route}`;

        // Demo map placement based on the bus index.
        marker.style.left = `${20 + (index * 22) % 65}%`;
        marker.style.top = `${35 + (index * 18) % 45}%`;

        marker.innerHTML = `<span>🚌</span>`;
        holder.appendChild(marker);
    });
}

loadBuses();
setInterval(loadBuses, 30000);
