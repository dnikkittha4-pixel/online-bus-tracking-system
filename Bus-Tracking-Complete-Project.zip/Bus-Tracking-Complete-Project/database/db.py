import os
import sqlite3
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "bus_tracking.db")

def get_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS buses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bus_number TEXT NOT NULL UNIQUE,
            route TEXT NOT NULL,
            driver_name TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'Running',
            speed REAL NOT NULL DEFAULT 0,
            last_updated TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    count = db.execute("SELECT COUNT(*) AS count FROM buses").fetchone()["count"]
    if count == 0:
        sample_buses = [
            ("BUS101", "Hosur - Bangalore", "Arun Kumar", 12.7409, 77.8253, "Running", 38),
            ("BUS102", "Hosur - Krishnagiri", "Suresh", 12.7350, 77.8290, "Running", 42),
            ("BUS103", "Hosur - Salem", "Ravi", 12.7300, 77.8200, "Stopped", 0),
            ("BUS104", "Hosur - Bangalore", "Karthik", 12.7480, 77.8300, "Running", 35)
        ]
        db.executemany("""
            INSERT INTO buses
            (bus_number, route, driver_name, latitude, longitude, status, speed)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, sample_buses)

    db.commit()
    db.close()

if __name__ == "__main__":
    init_db()
    print(f"Database ready: {DB_PATH}")
