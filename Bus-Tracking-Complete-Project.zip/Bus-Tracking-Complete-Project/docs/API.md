# REST API Documentation

Base URL:

```text
http://127.0.0.1:5000
```

## 1. Health Check

GET `/api/health`

Response:

```json
{
  "status": "ok",
  "service": "Bus Tracking API"
}
```

## 2. Get All Buses

GET `/api/buses`

Returns all bus records.

## 3. Get One Bus

GET `/api/buses/1`

Returns one bus by database ID.

## 4. Add Bus

POST `/api/buses`

Example JSON:

```json
{
  "bus_number": "BUS105",
  "route": "Hosur - Bangalore",
  "driver_name": "Mani",
  "latitude": 12.74,
  "longitude": 77.82,
  "status": "Running",
  "speed": 35
}
```

## 5. Update Bus GPS

PUT `/api/buses/1/location`

Example JSON:

```json
{
  "latitude": 12.7415,
  "longitude": 77.8270,
  "speed": 40,
  "status": "Running"
}
```

## 6. Route Summary

GET `/api/routes`

Returns each route and its bus count.
