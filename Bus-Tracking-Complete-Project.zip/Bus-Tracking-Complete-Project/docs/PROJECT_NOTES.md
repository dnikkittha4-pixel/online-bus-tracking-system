# Project Notes

## Modules

1. Passenger dashboard
2. Bus database
3. Bus REST API
4. GPS location update
5. Route summary
6. Bus status monitoring
7. Search and filtering

## Future Enhancements

- OpenStreetMap/Leaflet live map
- Driver mobile GPS sender
- Login for admin and driver
- ETA calculation
- Geofencing
- Notifications
- Route history
- Cloud database
- Deployment
