from flask import Flask, render_template, jsonify, request
from database.db import init_db, get_db

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

init_db()

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/buses")
def get_buses():
    db = get_db()
    rows = db.execute("""
        SELECT id, bus_number, route, driver_name, latitude, longitude,
               status, speed, last_updated
        FROM buses ORDER BY bus_number
    """).fetchall()
    db.close()
    return jsonify([dict(row) for row in rows])

@app.get("/api/buses/<int:bus_id>")
def get_bus(bus_id):
    db = get_db()
    row = db.execute("SELECT * FROM buses WHERE id = ?", (bus_id,)).fetchone()
    db.close()
    if not row:
        return jsonify({"error": "Bus not found"}), 404
    return jsonify(dict(row))

@app.post("/api/buses")
def add_bus():
    data = request.get_json(silent=True) or {}
    required = ["bus_number", "route", "driver_name"]
    missing = [field for field in required if not data.get(field)]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    db = get_db()
    try:
        cur = db.execute("""
            INSERT INTO buses
            (bus_number, route, driver_name, latitude, longitude, status, speed)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            data["bus_number"],
            data["route"],
            data["driver_name"],
            data.get("latitude", 12.7409),
            data.get("longitude", 77.8253),
            data.get("status", "Running"),
            data.get("speed", 0)
        ))
        db.commit()
        bus_id = cur.lastrowid
        row = db.execute("SELECT * FROM buses WHERE id = ?", (bus_id,)).fetchone()
        db.close()
        return jsonify(dict(row)), 201
    except Exception as exc:
        db.close()
        return jsonify({"error": str(exc)}), 400

@app.put("/api/buses/<int:bus_id>/location")
def update_location(bus_id):
    data = request.get_json(silent=True) or {}
    if "latitude" not in data or "longitude" not in data:
        return jsonify({"error": "latitude and longitude are required"}), 400

    db = get_db()
    row = db.execute("SELECT id FROM buses WHERE id = ?", (bus_id,)).fetchone()
    if not row:
        db.close()
        return jsonify({"error": "Bus not found"}), 404

    db.execute("""
        UPDATE buses
        SET latitude = ?, longitude = ?, speed = ?, status = ?, last_updated = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (
        data["latitude"],
        data["longitude"],
        data.get("speed", 0),
        data.get("status", "Running"),
        bus_id
    ))
    db.commit()
    updated = db.execute("SELECT * FROM buses WHERE id = ?", (bus_id,)).fetchone()
    db.close()
    return jsonify(dict(updated))

@app.get("/api/routes")
def get_routes():
    db = get_db()
    rows = db.execute("""
        SELECT route, COUNT(*) AS bus_count
        FROM buses GROUP BY route ORDER BY route
    """).fetchall()
    db.close()
    return jsonify([dict(row) for row in rows])

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Bus Tracking API"})

if __name__ == "__main__":
    app.run(debug=True)
